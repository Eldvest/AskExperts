export default {
  plugins: {
    autoprefixer: {},
    'postcss-nesting': {},
    'postcss-custom-media': {},
    '@csstools/postcss-media-minmax': {},
  },
};
